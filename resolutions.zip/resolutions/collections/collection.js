Resolutions = new Mongo.Collection('resolutions');
